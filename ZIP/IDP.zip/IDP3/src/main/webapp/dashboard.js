document.getElementById("quickop1").addEventListener("click", fun1);
document.getElementById("quickop2").addEventListener("click", fun2);
document.getElementById("quickop3").addEventListener("click", fun3);
document.getElementById("quickop4").addEventListener("click", fun4);
document.getElementById("quickop5").addEventListener("click", fun5);
document.getElementById("quickop6").addEventListener("click", fun6);
document.getElementById("quickop7").addEventListener("click", fun7);
document.getElementById("quickop8").addEventListener("click", fun8);
document.getElementById("quickop").addEventListener("click", () => {
  document.getElementById("quickopdrop1").style.display = "none";
  document.getElementById("quickopdrop2").style.display = "none";
  document.getElementById("quickopdrop3").style.display = "none";
  document.getElementById("quickopdrop4").style.display = "none";
  document.getElementById("quickopdrop5").style.display = "none";
  document.getElementById("quickopdrop6").style.display = "none";
  document.getElementById("quickopdrop7").style.display = "none";
  document.getElementById("quickopdrop8").style.display = "none";
});
function fun1() {
  
  if(document.getElementById("quickopdrop1").style.display == "block"){
  document.getElementById("quickopdrop1").style.display = "none";
  quickop1ex.src="icons8-plus-+-240.png";

}
  else{
    document.getElementById("quickopdrop1").style.display="block";
    quickop1ex.src="icons8-minus-96.png";
  }
  quickop2ex.src="icons8-plus-+-240.png";
  quickop3ex.src="icons8-plus-+-240.png";
  quickop4ex.src="icons8-plus-+-240.png";
  quickop5ex.src="icons8-plus-+-240.png";
  quickop6ex.src="icons8-plus-+-240.png";
  quickop7ex.src="icons8-plus-+-240.png";
  quickop8ex.src="icons8-plus-+-240.png";


  document.getElementById("quickopdrop2").style.display = "none";
  document.getElementById("quickopdrop3").style.display = "none";
  document.getElementById("quickopdrop4").style.display = "none";
  document.getElementById("quickopdrop5").style.display = "none";
  document.getElementById("quickopdrop6").style.display = "none";
  document.getElementById("quickopdrop7").style.display = "none";
  document.getElementById("quickopdrop8").style.display = "none";

}
function fun2() {
  if(document.getElementById("quickopdrop2").style.display == "block"){
    document.getElementById("quickopdrop2").style.display = "none";
    quickop2ex.src="icons8-plus-+-240.png";
  
  }
    else{
      document.getElementById("quickopdrop2").style.display="block";
      quickop2ex.src="icons8-minus-96.png";
  
    }
    quickop1ex.src="icons8-plus-+-240.png";
    quickop3ex.src="icons8-plus-+-240.png";
    quickop4ex.src="icons8-plus-+-240.png";
    quickop5ex.src="icons8-plus-+-240.png";
    quickop6ex.src="icons8-plus-+-240.png";
    quickop7ex.src="icons8-plus-+-240.png";
    quickop8ex.src="icons8-plus-+-240.png";
  
  
    document.getElementById("quickopdrop1").style.display = "none";
    document.getElementById("quickopdrop3").style.display = "none";
    document.getElementById("quickopdrop4").style.display = "none";
    document.getElementById("quickopdrop5").style.display = "none";
    document.getElementById("quickopdrop6").style.display = "none";
    document.getElementById("quickopdrop7").style.display = "none";
    document.getElementById("quickopdrop8").style.display = "none";
  
}
function fun3() {
  if(document.getElementById("quickopdrop3").style.display == "block"){
    document.getElementById("quickopdrop3").style.display = "none";
    quickop3ex.src="icons8-plus-+-240.png";
  
  }
    else{
      document.getElementById("quickopdrop3").style.display="block";
      quickop3ex.src="icons8-minus-96.png";
  
    }
    quickop2ex.src="icons8-plus-+-240.png";
    quickop1ex.src="icons8-plus-+-240.png";
    quickop4ex.src="icons8-plus-+-240.png";
    quickop5ex.src="icons8-plus-+-240.png";
    quickop6ex.src="icons8-plus-+-240.png";
    quickop7ex.src="icons8-plus-+-240.png";
    quickop8ex.src="icons8-plus-+-240.png";
  
  
    document.getElementById("quickopdrop2").style.display = "none";
    document.getElementById("quickopdrop1").style.display = "none";
    document.getElementById("quickopdrop4").style.display = "none";
    document.getElementById("quickopdrop5").style.display = "none";
    document.getElementById("quickopdrop6").style.display = "none";
    document.getElementById("quickopdrop7").style.display = "none";
    document.getElementById("quickopdrop8").style.display = "none";
}
function fun4() {
  if(document.getElementById("quickopdrop4").style.display == "block"){
    document.getElementById("quickopdrop4").style.display = "none";
    quickop4ex.src="icons8-plus-+-240.png";
  
  }
    else{
      document.getElementById("quickopdrop4").style.display="block";
      quickop4ex.src="icons8-minus-96.png";
  
    }
    quickop2ex.src="icons8-plus-+-240.png";
    quickop3ex.src="icons8-plus-+-240.png";
    quickop1ex.src="icons8-plus-+-240.png";
    quickop5ex.src="icons8-plus-+-240.png";
    quickop6ex.src="icons8-plus-+-240.png";
    quickop7ex.src="icons8-plus-+-240.png";
    quickop8ex.src="icons8-plus-+-240.png";
  
  
    document.getElementById("quickopdrop2").style.display = "none";
    document.getElementById("quickopdrop3").style.display = "none";
    document.getElementById("quickopdrop1").style.display = "none";
    document.getElementById("quickopdrop5").style.display = "none";
    document.getElementById("quickopdrop6").style.display = "none";
    document.getElementById("quickopdrop7").style.display = "none";
    document.getElementById("quickopdrop8").style.display = "none";
}
function fun5() {
  if(document.getElementById("quickopdrop5").style.display == "block"){
    document.getElementById("quickopdrop5").style.display = "none";
    quickop5ex.src="icons8-plus-+-240.png";
  
  }
    else{
      document.getElementById("quickopdrop5").style.display="block";
      quickop5ex.src="icons8-minus-96.png";
  
    }
    quickop2ex.src="icons8-plus-+-240.png";
    quickop3ex.src="icons8-plus-+-240.png";
    quickop4ex.src="icons8-plus-+-240.png";
    quickop1ex.src="icons8-plus-+-240.png";
    quickop6ex.src="icons8-plus-+-240.png";
    quickop7ex.src="icons8-plus-+-240.png";
    quickop8ex.src="icons8-plus-+-240.png";

    document.getElementById("quickopdrop2").style.display = "none";
    document.getElementById("quickopdrop3").style.display = "none";
    document.getElementById("quickopdrop4").style.display = "none";
    document.getElementById("quickopdrop1").style.display = "none";
    document.getElementById("quickopdrop6").style.display = "none";
    document.getElementById("quickopdrop7").style.display = "none";
    document.getElementById("quickopdrop8").style.display = "none";
}

function fun6() {
  if(document.getElementById("quickopdrop6").style.display == "block"){
    document.getElementById("quickopdrop6").style.display = "none";
    quickop6ex.src="icons8-plus-+-240.png";
  
  }
    else{
      document.getElementById("quickopdrop6").style.display="block";
      quickop6ex.src="icons8-minus-96.png";
  
    }
    quickop2ex.src="icons8-plus-+-240.png";
    quickop3ex.src="icons8-plus-+-240.png";
    quickop4ex.src="icons8-plus-+-240.png";
    quickop5ex.src="icons8-plus-+-240.png";
    quickop1ex.src="icons8-plus-+-240.png";
    quickop7ex.src="icons8-plus-+-240.png";
    quickop8ex.src="icons8-plus-+-240.png";
  
  
    document.getElementById("quickopdrop2").style.display = "none";
    document.getElementById("quickopdrop3").style.display = "none";
    document.getElementById("quickopdrop4").style.display = "none";
    document.getElementById("quickopdrop5").style.display = "none";
    document.getElementById("quickopdrop1").style.display = "none";
    document.getElementById("quickopdrop7").style.display = "none";
    document.getElementById("quickopdrop8").style.display = "none";
}

function fun7() {
  if(document.getElementById("quickopdrop7").style.display == "block"){
    document.getElementById("quickopdrop7").style.display = "none";
    quickop7ex.src="icons8-plus-+-240.png";
  
  }
    else{
      document.getElementById("quickopdrop7").style.display="block";
      quickop7ex.src="icons8-minus-96.png";
  
    }
    quickop2ex.src="icons8-plus-+-240.png";
    quickop3ex.src="icons8-plus-+-240.png";
    quickop4ex.src="icons8-plus-+-240.png";
    quickop5ex.src="icons8-plus-+-240.png";
    quickop6ex.src="icons8-plus-+-240.png";
    quickop1ex.src="icons8-plus-+-240.png";
    quickop8ex.src="icons8-plus-+-240.png";
  
  
    document.getElementById("quickopdrop2").style.display = "none";
    document.getElementById("quickopdrop3").style.display = "none";
    document.getElementById("quickopdrop4").style.display = "none";
    document.getElementById("quickopdrop5").style.display = "none";
    document.getElementById("quickopdrop6").style.display = "none";
    document.getElementById("quickopdrop1").style.display = "none";
    document.getElementById("quickopdrop8").style.display = "none";
}

function fun8() {
  if(document.getElementById("quickopdrop8").style.display == "block"){
    document.getElementById("quickopdrop8").style.display = "none";
    quickop8ex.src="icons8-plus-+-240.png";
  
  }
    else{
      document.getElementById("quickopdrop8").style.display="block";
      quickop8ex.src="icons8-minus-96.png";
  
    }
    quickop2ex.src="icons8-plus-+-240.png";
    quickop3ex.src="icons8-plus-+-240.png";
    quickop4ex.src="icons8-plus-+-240.png";
    quickop5ex.src="icons8-plus-+-240.png";
    quickop6ex.src="icons8-plus-+-240.png";
    quickop7ex.src="icons8-plus-+-240.png";
    quickop1ex.src="icons8-plus-+-240.png";
  
  
    document.getElementById("quickopdrop2").style.display = "none";
    document.getElementById("quickopdrop3").style.display = "none";
    document.getElementById("quickopdrop4").style.display = "none";
    document.getElementById("quickopdrop5").style.display = "none";
    document.getElementById("quickopdrop6").style.display = "none";
    document.getElementById("quickopdrop7").style.display = "none";
    document.getElementById("quickopdrop1").style.display = "none";
}