document.getElementById("quickopdropbuttons1a1").addEventListener("click", function() { 
    location.href = "maintainstock.html";
});

document.getElementById("quickop").addEventListener("click", function() {
    location.href = "dashboard.html";
});